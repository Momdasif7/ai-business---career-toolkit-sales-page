import React from 'react';
import { BuyButton } from './BuyButton';
import { CheckCircle2, Cpu, Brain, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

export const Hero: React.FC = () => {
  return (
    <div className="relative overflow-hidden bg-slate-950 pt-16 pb-20 lg:pt-32 lg:pb-28">
      {/* Background Effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-7xl pointer-events-none opacity-20">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-500 rounded-full blur-[128px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent-600 rounded-full blur-[128px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900/50 px-4 py-1.5 text-sm font-medium text-brand-400 backdrop-blur-sm mb-8">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
            </span>
            Global Edition | 2025
          </div>
          
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl lg:text-7xl mb-6">
            Master AI Without <br className="hidden md:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-accent-500">
              Losing Your Authenticity
            </span>
          </h1>

          <p className="mx-auto max-w-2xl text-lg text-slate-400 mb-10 leading-relaxed">
            Practical Frameworks, Workflows & AI Resources for Modern Professionals. 
            Stop random prompting. Start thinking strategically.
          </p>

          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row mb-12">
            <BuyButton />
            <a href="#what-is-inside" className="text-sm font-semibold text-slate-400 hover:text-white transition-colors">
              See what's inside &rarr;
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
            {[
              { icon: Brain, title: "Clear Thinking", desc: "Beats fast tools" },
              { icon: ShieldCheck, title: "Authenticity", desc: "Beats polish" },
              { icon: Cpu, title: "Strategic Use", desc: "Beats random experiments" }
            ].map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 rounded-xl border border-slate-800 bg-slate-900/50 p-4 backdrop-blur-sm">
                <item.icon className="h-6 w-6 text-brand-500 shrink-0" />
                <div>
                  <h3 className="font-semibold text-white">{item.title}</h3>
                  <p className="text-sm text-slate-400">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};