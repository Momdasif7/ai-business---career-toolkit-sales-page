import React from 'react';
import { Section, FadeIn } from './Section';

export const Preview: React.FC = () => {
  return (
    <Section>
      <FadeIn>
        <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-white mb-4">Framework Peek: The Collaboration Model</h2>
                <p className="text-slate-400">
                    We don't just give you prompts. We teach you how to partner with intelligence.
                </p>
            </div>

            <div className="bg-slate-800 rounded-xl overflow-hidden shadow-2xl border border-slate-700">
                <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-700">
                    <div className="p-8 bg-slate-800/50">
                        <h4 className="text-xl font-bold text-brand-400 mb-4">You Bring</h4>
                        <ul className="space-y-3 text-slate-300 text-sm">
                            <li className="flex gap-2"><span className="text-brand-500">•</span> Judgment & Values</li>
                            <li className="flex gap-2"><span className="text-brand-500">•</span> Context & Nuance</li>
                            <li className="flex gap-2"><span className="text-brand-500">•</span> Accountability & Credibility</li>
                            <li className="flex gap-2"><span className="text-brand-500">•</span> Final Decision Making</li>
                        </ul>
                    </div>
                    <div className="p-8 bg-slate-900/50">
                        <h4 className="text-xl font-bold text-accent-400 mb-4">AI Brings</h4>
                        <ul className="space-y-3 text-slate-300 text-sm">
                            <li className="flex gap-2"><span className="text-accent-500">•</span> Speed & Volume</li>
                            <li className="flex gap-2"><span className="text-accent-500">•</span> Pattern Recognition</li>
                            <li className="flex gap-2"><span className="text-accent-500">•</span> Draft Generation</li>
                            <li className="flex gap-2"><span className="text-accent-500">•</span> Iterative Analysis</li>
                        </ul>
                    </div>
                </div>
                <div className="p-6 bg-slate-950 border-t border-slate-700 text-center">
                    <p className="text-white font-medium">
                        <span className="text-red-400 line-through mr-2">You ask → AI Creates → You Submit</span>
                        <span className="text-green-400">You Think → You Direct → AI Helps → You Decide</span>
                    </p>
                </div>
            </div>
        </div>
      </FadeIn>
    </Section>
  );
};