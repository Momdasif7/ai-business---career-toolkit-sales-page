import React from 'react';
import { Section, FadeIn } from './Section';
import { BuyButton } from './BuyButton';
import { Check } from 'lucide-react';

export const Pricing: React.FC = () => {
  return (
    <Section id="pricing" darker className="relative overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="relative max-w-3xl mx-auto text-center">
        <FadeIn>
          <h2 className="text-4xl font-extrabold text-white mb-6">
            Ready to Future-Proof Your Career?
          </h2>
          <p className="text-xl text-slate-300 mb-10">
            Get instant access to the Complete Guide, Prompt Vault, Templates, and Implementation Roadmap.
          </p>
          
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-8 mb-10 shadow-2xl transform hover:scale-[1.01] transition-transform duration-300">
            <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-8 text-slate-300 text-sm">
                <div className="flex items-center gap-2"><Check className="text-green-400 h-4 w-4"/> Digital PDF Guide</div>
                <div className="flex items-center gap-2"><Check className="text-green-400 h-4 w-4"/> 50+ Copy-Paste Prompts</div>
                <div className="flex items-center gap-2"><Check className="text-green-400 h-4 w-4"/> Workflow Templates</div>
                <div className="flex items-center gap-2"><Check className="text-green-400 h-4 w-4"/> 2025 Global Edition</div>
            </div>

            <BuyButton fullWidth className="text-xl py-5" />
            
            <p className="mt-4 text-xs text-slate-500">
                Secure payment via Digistore24. Instant digital delivery.
            </p>
          </div>

          <div className="text-slate-500 text-sm space-y-2">
            <p>© 2025 AI Business & Career Toolkit. All Rights Reserved.</p>
            <p className="text-xs max-w-lg mx-auto">
                Disclaimer: This toolkit is for educational purposes only. No guarantees of income or specific results. 
                You are responsible for your application of this material.
            </p>
          </div>
        </FadeIn>
      </div>
    </Section>
  );
};