import React, { useState, useMemo } from 'react';
import { Section, FadeIn } from './Section';
import { Search, X, Copy, Check, Eye, Filter, Zap, LayoutGrid, Award } from 'lucide-react';

interface Prompt {
  id: string;
  title: string;
  category: string;
  domain: string;
  problem: string;
  technique: string;
  difficulty: string;
  useCase: string;
  explanation: string;
  prompt: string;
  output: string;
  customize: string;
}

const PROMPTS_DATA: Prompt[] = [
    // ===== BUSINESS STRATEGY =====
    {
        id: "B1.1",
        title: "Revenue Leak Diagnostic Engine",
        category: "business",
        domain: "Revenue Optimization",
        problem: "Hitting targets but profits don't match. Revenue leaks everywhere you can't see them.",
        technique: "cot",
        difficulty: "intermediate",
        useCase: "When you have good revenue but cash flow problems or margins are lower than expected",
        explanation: "Uses Chain-of-Thought reasoning to systematically identify hidden revenue leaks across 7 key areas of your business.",
        prompt: `You are a revenue leak detective with 15 years of experience analyzing profitable businesses.

CONTEXT: A founder is analyzing their business profitability and suspects hidden revenue leaks.

BUSINESS MODEL:
[FOUNDER PROVIDES: Revenue model, customer segments, pricing, main expenses]

YOUR TASK: Identify the HIDDEN revenue leaks by analyzing 7 critical areas.

For EACH area, think through these steps:
1. What revenue is promised but customers are finding workarounds to avoid paying?
2. What costs hide inside operational expenses that scale with revenue?
3. What discounts/negotiation patterns show real pricing power?
4. What features cost disproportionate time vs. perceived value?
5. What customer segments have structural profitability problems?
6. What processes have duplicated effort that nobody sees?
7. What partnerships/channels have hidden negative margin?

For each leak identified, calculate:
- Monthly revenue impact
- Root cause (not surface symptom)
- Quick win fix (implementable in <2 weeks)
- Long-term structural fix

Output: Ranked list of top 5 revenue leaks with quantified impact.`,
        output: "5-10 specific revenue leaks identified with exact monthly impact, root cause analysis, and ranked fixes",
        customize: "For SaaS: Change to focus on upgrade rates and feature usage. For services: Focus on project scope creep."
    },
    {
        id: "B1.2",
        title: "Unit Economics Reality Check",
        category: "business",
        domain: "Revenue Optimization",
        problem: "Profitable on paper but unit economics might be broken at scale. Uncertainty about viability.",
        technique: "sparc",
        difficulty: "intermediate",
        useCase: "When you need to validate if your business model actually works at scale",
        explanation: "SPARC framework separates System (business model), Persona (financial analyst), Actions (calculations), Reasoning (why numbers matter), Context (market conditions).",
        prompt: `SYSTEM: You are a unit economics auditor for scalable businesses.

PERSONA 1 - Financial Analyst: Calculate precise metrics
PERSONA 2 - Growth Strategist: Identify scaling problems  
PERSONA 3 - Risk Manager: Spot structural issues

BUSINESS DATA:
[User provides: Revenue per customer, cost to acquire, cost to serve, retention]

EACH PERSONA MUST:
1. Calculate LTV (lifetime value): annual profit × lifespan
2. Calculate CAC (customer acquisition cost): total acquisition spend ÷ customers
3. Calculate LTV:CAC ratio: if <2x, problematic
4. Calculate payback period: months until CAC is recovered
5. Calculate contribution margin: (revenue - COGS) ÷ revenue

THEN REASON:
- Which metric is the bottleneck?
- At 10x scale, does margin disappear?
- Can we profitably acquire customers at scale?
- Is this a venture business or lifestyle business?

OUTPUT: Clear diagnosis + highest-leverage fix`,
        output: "Exact unit economics with LTV:CAC ratio, bottleneck identification, and scale analysis",
        customize: "For SaaS: Include MRR and churn. For marketplaces: Include take rate and supply balance."
    },
    {
        id: "B1.3",
        title: "Pricing Power Assessment",
        category: "business",
        domain: "Revenue Optimization",
        problem: "Underpricing by 50-300%. Too afraid to raise prices. Leaving money on table.",
        technique: "cot",
        difficulty: "beginner",
        useCase: "Before any pricing change, validate you have actual pricing power",
        explanation: "Step-by-step reasoning through 6 tests that reveal whether customers will accept price increases.",
        prompt: `You are a pricing strategist. Assess if this business can raise prices without losing customers.

CURRENT SITUATION:
- Current price: [X]
- How long at this price: [Y] months
- Competitors' prices: [Z]

CONDUCT 6 TESTS (in order):

1. ELASTICITY TEST: If we raise 20%, what % of customers leave?
   - CAC is $[X]. LTV is $[Y].
   - If we lose 10% but raise 20%, math: (LTV × 0.9) vs (LTV × 1.0 × 0.8)
   - Does LTV go up or down?

2. CUSTOMER SENTIMENT TEST: Ask 10 customers: "Would you stay if price +20%?"
   - Count yes answers. What %?

3. VALUE TEST: What economic value do we create?
   - If we save customer $50k/year, we could charge $10k/year
   - Are we capturing value proportional to value delivered?

4. COMPETITOR TEST: What do competitors charge?
   - Are we premium, mid-market, or discount?

5. BUYER PROFILE TEST: What's customer budget?
   - If our price is <1% of their budget, we can raise
   - If >10% of budget, price is sensitive

6. WILLINGNESS TEST: What would customers actually pay?
   - Usually 2-3x current price

CONCLUSION: Can you raise price? By how much? What will you change?`,
        output: "Optimal price point with confidence level, customer reaction prediction, and change strategy",
        customize: "For B2B: Focus on budget and willingness to pay. For B2C: Focus on demand elasticity."
    },
    {
        id: "B1.4",
        title: "Market Fit Validation Engine",
        category: "business",
        domain: "Revenue Optimization",
        problem: "Think you have market-product fit. Actually operating on narrative and hope.",
        technique: "cot",
        difficulty: "advanced",
        useCase: "When you need honest assessment of whether you have real PMF or false signal",
        explanation: "6-test framework that distinguishes real product-market fit from early adopter love and narrative.",
        prompt: `CRITICAL: You are assessing whether this startup has REAL product-market fit or FAKE fit.

SITUATION:
- Monthly revenue: $[X]
- Total customers: [#]
- Retention rate: [#]%
- CAC: $[X]
- LTV: $[X]
- Monthly growth: [#]%

THE 6 TESTS (each reveals real signal):

1. RETENTION TEST (Most Important)
   - Calculate MoM retained revenue for 3 months
   - Real fit: 90%+ retention (customers stay and expand)
   - Fake fit: 80%+ retention (constant churn you ignore)
   - Your result: ___

2. GROWTH QUALITY TEST
   - % organic (word-of-mouth) vs. paid acquisition
   - % expansion (existing customers) vs. new customers
   - Real fit: 40%+ organic, 30%+ expansion
   - Fake fit: 90%+ paid, 90%+ new customers
   - Your result: ___

3. DEFENSIBILITY TEST
   - Why would customers leave?
   - Would switching cost be high?
   - Real fit: Reasons are hard/expensive to solve
   - Fake fit: Reasons are easy (you just don't prioritize)
   - Your result: ___

4. MARKET EXPANSION TEST
   - Of total addressable market, what % tried product?
   - Of those who tried, what % stuck?
   - Real fit: Tried >20%, Stuck >30%
   - Fake fit: Tried <10%, Stuck <15%
   - Your result: ___

5. DEMAND TEST
   - Is demand inbound (customers asking) or outbound (you hunting)?
   - Real fit: 40%+ inbound
   - Fake fit: 90%+ outbound
   - Your result: ___

6. EMBEDDING TEST
   - If you disappeared, would customers:
   - A) Panic (embedded) - 70%+ real fit
   - B) Shrug (replaceable) - 40%+ fake fit
   - Your result: ___

DIAGNOSIS:
- Count your passing tests: [#]/6
- If <3: Fake fit, need changes
- If 3-4: Partial fit, addressable issues
- If 5-6: Real fit, scale it

What single change would improve your weakest test?`,
        output: "Honest assessment (Real/Fake/Partial fit) + weakest signal + highest-leverage change",
        customize: "For SaaS: Focus on expansion revenue and churn. For marketplaces: Focus on supply stickiness."
    },
    // ... Additional prompts from your code ...
    {
        id: "C1.1",
        title: "Leadership Readiness Assessment",
        category: "career",
        domain: "Leadership & Management",
        problem: "Want to be promoted to leadership but not sure if you're ready. What's missing?",
        technique: "cot",
        difficulty: "intermediate",
        useCase: "Before pursuing senior leadership role, assess your actual readiness",
        explanation: "5-test framework evaluates: strategic thinking, people leadership, visibility, results, and sponsorship.",
        prompt: `ASSESSMENT: Are you actually ready for senior leadership?

CURRENT ROLE: [Title]
TARGET ROLE: [Title]
Years in current role: [#]

TEST 1: STRATEGIC THINKING
Do you think beyond your current role?
- Can you articulate company strategy? (Y/N)
- Do leaders ask your opinion on strategy? (Y/N)
- Do you propose strategic initiatives? (Y/N)
- Can you see 2-3 year trajectory? (Y/N)
- Score: [#]/4

TEST 2: PEOPLE LEADERSHIP
Are you building leaders or just managing people?
- Are your people developing/getting promoted? (Y/N)
- Would people follow you or just obey? (Y/N)
- Can you give hard feedback with care? (Y/N)
- Do people ask you for mentoring? (Y/N)
- Score: [#]/4

TEST 3: VISIBILITY
Do leaders know you exist?
- Do you speak in all-hands? (Frequency: Never/Sometimes/Always)
- Are you known for something specific? (Y/N)
- Do you have relationships with other leaders? (Y/N)
- Would leaders hire you for critical project? (Y/N)
- Score: [#]/4

TEST 4: RESULTS
Are you consistently exceeding expectations?
- Are your metrics trending up? (Y/N)
- Last year: Outperformed [#]% of peers
- Do leaders use you as example? (Y/N)
- Can you quantify impact? (Y/N)
- Score: [#]/4

TEST 5: SPONSORSHIP
Do you have a sponsor?
- Is your boss advocating for you? (Y/N)
- Would another leader fight for you? (Y/N)
- Do people want you on their team? (Y/N)
- Is there a clear path to next role? (Y/N)
- Score: [#]/4

TOTAL READINESS SCORE: [#]/20

INTERPRETATION:
- 16-20: You're ready. Apply for next role.
- 12-15: You're mostly ready. Address top gaps in 90 days, then apply.
- 8-11: You're not ready. Create 6-month development plan.
- <8: You need major growth. Not ready for 12+ months.

GAP ANALYSIS:
Lowest score: ___
This is your priority.
How will you improve it in 90 days?`,
        output: "Readiness score + gap analysis + 90-day development plan",
        customize: "For technical leaders: Add technical depth requirement. For managers: Add team metrics."
    },
    {
        id: "S1.1",
        title: "Sales Pipeline Architecture",
        category: "sales",
        domain: "Sales Strategy",
        problem: "Pipeline is empty or unpredictable. Forecast is guesswork. No system for consistency.",
        technique: "cot",
        difficulty: "advanced",
        useCase: "When you need repeatable, predictable pipeline generation",
        explanation: "Designs complete pipeline system from prospecting through closing with activity targets.",
        prompt: `PIPELINE ARCHITECTURE: Design your sales system.

TARGET: [#] deals/month at [#]% close rate and $[X] avg deal = $[Y] revenue/month

WORK BACKWARDS:

Deals needed per month: [#] 
Prospects needed (at [#]% close): [#]
Conversations needed (at [#]% prospect rate): [#]
Outreaches needed (at [#]% conversation rate): [#]

DAILY ACTIVITY REQUIRED:
- Outreaches/day: [#]
- Conversations/day: [#]
- Hours/day on prospecting: [#]

PIPELINE BY STAGE:
Stage 1 (Leads): [#] leads
Stage 2 (Prospects): [#] prospects
Stage 3 (Qualified): [#] qualified
Stage 4 (Negotiating): [#] negotiating
Stage 5 (Closing): [#] closing

EACH WEEK:
- Generate [#] new leads
- Convert [#] leads to prospects
- Qualify [#] prospects
- Close [#] deals

QUALITY METRICS:
- Lead quality: Are they right fit? [#]% yes
- Deal quality: Can you deliver value? [#]% yes
- Close rate: Of qualified prospects, [#]% close

ACTIVITY TRACKING:
Weekly metrics:
- Outreaches: [#] (need [#])
- Conversations: [#] (need [#])
- Proposals: [#] (need [#])
- Closes: [#] (need [#])

Are you on track? (Y/N)
If N: What's blocking activity?

FORECAST:
30-day forecast: $[X] deals expected
60-day forecast: $[X] deals expected
90-day forecast: $[X] deals expected

Are forecasts based on math or optimism?`,
        output: "Daily/weekly activity targets + pipeline stages + forecast with confidence",
        customize: "For enterprise: Focus on long sales cycles. For SMB: Focus on high volume, short cycles."
    }
];

export const PromptVault: React.FC = () => {
    const [filters, setFilters] = useState({
        category: '',
        technique: '',
        difficulty: '',
        search: ''
    });
    const [activePrompt, setActivePrompt] = useState<Prompt | null>(null);
    const [copied, setCopied] = useState(false);

    const filteredPrompts = useMemo(() => {
        return PROMPTS_DATA.filter(p => {
            const matchesCategory = !filters.category || p.category === filters.category;
            const matchesTechnique = !filters.technique || p.technique === filters.technique;
            const matchesDifficulty = !filters.difficulty || p.difficulty === filters.difficulty;
            const matchesSearch = !filters.search || 
                p.title.toLowerCase().includes(filters.search.toLowerCase()) || 
                p.problem.toLowerCase().includes(filters.search.toLowerCase());
            return matchesCategory && matchesTechnique && matchesDifficulty && matchesSearch;
        });
    }, [filters]);

    const handleCopy = (text: string) => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <Section id="prompt-vault" className="border-t border-slate-800">
            <FadeIn>
                <div className="text-center mb-12">
                    <span className="text-brand-400 font-semibold tracking-wider uppercase text-sm flex items-center justify-center gap-2 mb-4">
                        <Zap className="h-4 w-4" /> Interactive Demo
                    </span>
                    <h2 className="text-3xl font-extrabold text-white sm:text-4xl mb-4">
                        Inside the <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-accent-500">Prompt Vault</span>
                    </h2>
                    <p className="text-lg text-slate-400 max-w-3xl mx-auto">
                        Experience a selection of the production-grade prompts included in the toolkit.
                        Check out our prompt vault and learn how to implement this in the E-Book.
                    </p>
                </div>
            </FadeIn>

            {/* Controls */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8 shadow-xl">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="relative">
                        <Filter className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <select 
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500 appearance-none"
                            value={filters.category}
                            onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
                        >
                            <option value="">All Categories</option>
                            <option value="business">Business Strategy</option>
                            <option value="career">Career Development</option>
                            <option value="sales">Sales & Revenue</option>
                        </select>
                    </div>
                    
                    <div className="relative">
                        <LayoutGrid className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <select 
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500 appearance-none"
                            value={filters.technique}
                            onChange={(e) => setFilters(prev => ({ ...prev, technique: e.target.value }))}
                        >
                            <option value="">All Techniques</option>
                            <option value="cot">Chain-of-Thought</option>
                            <option value="sparc">SPARC Framework</option>
                            <option value="react">ReAct</option>
                        </select>
                    </div>

                    <div className="relative">
                        <Award className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <select 
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500 appearance-none"
                            value={filters.difficulty}
                            onChange={(e) => setFilters(prev => ({ ...prev, difficulty: e.target.value }))}
                        >
                            <option value="">All Levels</option>
                            <option value="beginner">Beginner</option>
                            <option value="intermediate">Intermediate</option>
                            <option value="advanced">Advanced</option>
                        </select>
                    </div>

                    <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-slate-500" />
                        <input 
                            type="text"
                            placeholder="Search prompts..."
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-brand-500"
                            value={filters.search}
                            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                        />
                    </div>
                </div>
            </div>

            {/* Grid */}
            {filteredPrompts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredPrompts.map((prompt) => (
                        <div 
                            key={prompt.id}
                            className="group flex flex-col bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-brand-500/50 hover:shadow-lg transition-all cursor-pointer relative overflow-hidden"
                            onClick={() => setActivePrompt(prompt)}
                        >
                            <div className="flex justify-between items-start mb-4">
                                <span className="inline-flex items-center px-2 py-1 rounded bg-slate-800 text-xs font-medium text-brand-400 border border-slate-700">
                                    {prompt.id}
                                </span>
                                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{prompt.category}</span>
                            </div>
                            
                            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-brand-400 transition-colors">
                                {prompt.title}
                            </h3>
                            
                            <p className="text-sm text-slate-400 mb-4 line-clamp-3 flex-grow">
                                {prompt.problem}
                            </p>

                            <div className="flex gap-2 mb-4">
                                <span className="text-[10px] uppercase font-bold px-2 py-1 bg-brand-900/20 text-brand-300 rounded border border-brand-900/50">
                                    {prompt.technique}
                                </span>
                                <span className="text-[10px] uppercase font-bold px-2 py-1 bg-slate-800 text-slate-300 rounded border border-slate-700">
                                    {prompt.difficulty}
                                </span>
                            </div>

                            <div className="mt-auto pt-4 border-t border-slate-800 flex justify-between items-center">
                                <span className="text-xs text-brand-500 font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                                    View Prompt <Eye className="h-3 w-3" />
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-20 bg-slate-900/50 rounded-xl border border-slate-800 border-dashed">
                    <p className="text-slate-400">No prompts found matching your filters.</p>
                </div>
            )}

            {/* Modal */}
            {activePrompt && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
                    <div 
                        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" 
                        onClick={() => setActivePrompt(null)} 
                    />
                    <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl animate-in fade-in zoom-in duration-300">
                        
                        {/* Modal Header */}
                        <div className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur border-b border-slate-800 px-6 py-4 flex justify-between items-center">
                            <div>
                                <div className="flex items-center gap-3 mb-1">
                                    <span className="text-sm font-bold text-brand-400">{activePrompt.id}</span>
                                    <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded uppercase">{activePrompt.category}</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">{activePrompt.title}</h3>
                            </div>
                            <button 
                                onClick={() => setActivePrompt(null)}
                                className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
                            >
                                <X className="h-6 w-6" />
                            </button>
                        </div>

                        {/* Modal Content */}
                        <div className="p-6 space-y-8">
                            
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <h4 className="text-sm font-semibold text-brand-400 uppercase tracking-wide">The Problem</h4>
                                    <p className="text-slate-300 text-sm leading-relaxed">{activePrompt.problem}</p>
                                </div>
                                <div className="space-y-2">
                                    <h4 className="text-sm font-semibold text-brand-400 uppercase tracking-wide">When to Use</h4>
                                    <p className="text-slate-300 text-sm leading-relaxed">{activePrompt.useCase}</p>
                                </div>
                            </div>

                            <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
                                <div className="bg-slate-800/50 px-4 py-2 border-b border-slate-800 flex justify-between items-center">
                                    <span className="text-xs font-mono text-slate-400">PROMPT TEMPLATE</span>
                                    <button 
                                        onClick={() => handleCopy(activePrompt.prompt)}
                                        className="text-xs flex items-center gap-1.5 text-brand-400 hover:text-brand-300 font-medium transition-colors"
                                    >
                                        {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                                        {copied ? 'Copied!' : 'Copy Prompt'}
                                    </button>
                                </div>
                                <pre className="p-4 text-sm text-slate-300 font-mono whitespace-pre-wrap leading-relaxed overflow-x-auto">
                                    {activePrompt.prompt}
                                </pre>
                            </div>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <h4 className="text-sm font-semibold text-brand-400 uppercase tracking-wide">Technique: {activePrompt.technique}</h4>
                                    <p className="text-slate-400 text-sm">{activePrompt.explanation}</p>
                                </div>
                                <div className="space-y-2">
                                    <h4 className="text-sm font-semibold text-brand-400 uppercase tracking-wide">How to Customize</h4>
                                    <p className="text-slate-400 text-sm">{activePrompt.customize}</p>
                                </div>
                            </div>
                        </div>

                        {/* Modal Footer */}
                        <div className="sticky bottom-0 bg-slate-900 border-t border-slate-800 p-4 flex justify-end gap-3">
                            <button 
                                onClick={() => setActivePrompt(null)}
                                className="px-4 py-2 text-sm font-medium text-slate-400 hover:text-white transition-colors"
                            >
                                Close
                            </button>
                            <button 
                                onClick={() => handleCopy(activePrompt.prompt)}
                                className="px-6 py-2 bg-brand-600 hover:bg-brand-500 text-white text-sm font-bold rounded-lg transition-all flex items-center gap-2"
                            >
                                <Copy className="h-4 w-4" /> Copy Full Prompt
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </Section>
    );
};