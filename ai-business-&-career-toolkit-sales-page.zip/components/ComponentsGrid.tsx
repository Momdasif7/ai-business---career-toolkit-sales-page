import React from 'react';
import { Section, FadeIn } from './Section';
import { BookOpen, Terminal, Layers, Map, FileText, Settings, Zap } from 'lucide-react';

export const ComponentsGrid: React.FC = () => {
  const components = [
    {
      icon: BookOpen,
      title: "Complete Guide (30 Pages)",
      desc: "Deep dive into AI thinking principles. Career strategies, business workflows, and ethical guidance. Your weekly reference manual."
    },
    {
      icon: Terminal,
      title: "Prompt Vault (Essential)",
      desc: "50+ customizable, research-backed prompts organized by use case. Includes instructions for modification and privacy."
    },
    {
      icon: Layers,
      title: "Workflow Templates",
      desc: "Ready-to-use frameworks: Resume reviews, LinkedIn optimization, SOP creation, and Weekly AI Reviews."
    },
    {
      icon: Map,
      title: "Implementation Roadmap",
      desc: "30-day quick start checklist + 90-day skill development path. Stop guessing and start building proficiency."
    },
    {
      icon: Settings,
      title: "Tool Usage Guide",
      desc: "Detailed overview of ChatGPT, Claude, and Gemini. Learn selection criteria and setup best practices."
    },
    {
      icon: Zap,
      title: "The 4-Step Framework",
      desc: "Learn the 'Clarify, Create, Critique, Customize' methodology to transform random prompting into strategic workflows."
    }
  ];

  return (
    <Section id="what-is-inside">
      <FadeIn>
        <div className="text-center mb-16">
          <span className="text-brand-500 font-semibold tracking-wider uppercase text-sm">Everything You Need</span>
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Inside the Toolkit
          </h2>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto">
            Designed as a practical reference system, not a linear course. Jump to what matters most for your current situation.
          </p>
        </div>
      </FadeIn>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {components.map((item, idx) => (
          <FadeIn key={idx} delay={idx * 0.1}>
            <div className="h-full group relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 p-8 transition-all hover:border-brand-500/50 hover:bg-slate-800/50">
              <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 rounded-full bg-brand-500/10 blur-xl group-hover:bg-brand-500/20 transition-all"></div>
              
              <div className="relative">
                <div className="inline-flex items-center justify-center rounded-lg bg-brand-500/10 p-3 text-brand-400 mb-6 group-hover:text-brand-300 group-hover:scale-110 transition-all duration-300">
                  <item.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                <p className="text-slate-400 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </div>
          </FadeIn>
        ))}
      </div>
    </Section>
  );
};