import React from 'react';
import { Brain } from 'lucide-react';

export const Navigation: React.FC = () => {
    return (
        <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <a href="#" className="flex items-center gap-2 text-white font-bold text-lg hover:opacity-80 transition-opacity">
                        <Brain className="h-6 w-6 text-brand-500" />
                        <span>AI Toolkit <span className="text-slate-500 font-normal">2025</span></span>
                    </a>
                    
                    <div className="hidden md:flex items-center gap-8">
                        <a href="#what-is-inside" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
                            Inside the Toolkit
                        </a>
                        <a href="#prompt-vault" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
                            Prompt Vault
                        </a>
                        <a href="#pricing" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
                            Pricing
                        </a>
                    </div>

                    <a 
                        href="https://www.checkout-ds24.com/product/658074" 
                        className="bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors border border-slate-700 hover:border-slate-600"
                    >
                        Buy Now
                    </a>
                </div>
            </div>
        </nav>
    );
};