import React from 'react';
import { Section, FadeIn } from './Section';
import { Check, X } from 'lucide-react';

export const WhoIsItFor: React.FC = () => {
  return (
    <Section darker className="bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="grid lg:grid-cols-2 gap-16 items-start">
        
        {/* For You */}
        <FadeIn>
          <div className="relative rounded-2xl bg-brand-950/20 border border-brand-900/30 p-8 lg:p-10">
            <h3 className="text-2xl font-bold text-white mb-8">This Toolkit Is For You If:</h3>
            <ul className="space-y-6">
              {[
                "You're a professional looking to integrate AI responsibly.",
                "You're a freelancer wanting efficiency without losing quality.",
                "You're an entrepreneur building AI-powered workflows.",
                "You're a career changer preparing for the 2025 job market.",
                "You want structured guidance beyond basic tool usage."
              ].map((item, i) => (
                <li key={i} className="flex gap-4">
                  <div className="flex-none rounded-full bg-brand-500/20 p-1 text-brand-400">
                    <Check className="h-5 w-5" />
                  </div>
                  <span className="text-slate-300 font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </FadeIn>

        {/* Not For You */}
        <FadeIn delay={0.2}>
          <div className="relative rounded-2xl bg-slate-900 p-8 lg:p-10 opacity-75 grayscale hover:grayscale-0 transition-all duration-500">
             <h3 className="text-2xl font-bold text-slate-200 mb-8">This Is NOT For You If:</h3>
            <ul className="space-y-6">
              {[
                "You want a 'magic button' for instant income.",
                "You're looking for copy-paste shortcuts without understanding.",
                "You aren't willing to review and refine AI outputs.",
                "You expect the AI to do 100% of the work for you.",
                "You want superficial hacks instead of deep principles."
              ].map((item, i) => (
                <li key={i} className="flex gap-4">
                  <div className="flex-none text-slate-500">
                    <X className="h-6 w-6" />
                  </div>
                  <span className="text-slate-400">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </FadeIn>

      </div>
    </Section>
  );
};