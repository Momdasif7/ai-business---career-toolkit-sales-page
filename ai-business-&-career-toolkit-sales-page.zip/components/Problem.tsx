import React from 'react';
import { Section, FadeIn } from './Section';
import { XCircle, CheckCircle } from 'lucide-react';

export const Problem: React.FC = () => {
  return (
    <Section darker className="border-y border-slate-800">
      <FadeIn>
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Are You Making These <span className="text-red-400">Common Mistakes?</span>
          </h2>
          <p className="mt-4 text-lg text-slate-400 max-w-2xl mx-auto">
            Most professionals treat AI like a magic vending machine. They put in a generic coin and get a generic product.
          </p>
        </div>
      </FadeIn>

      <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
        <FadeIn delay={0.1}>
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-red-400 mb-6 flex items-center gap-2">
              <XCircle className="h-6 w-6" /> The Amateur Approach
            </h3>
            <ul className="space-y-4">
              {[
                "Random Prompting: 'Write me a resume' → Copy paste → Wonder why it fails.",
                "Tool Hopping: Switching from ChatGPT to Claude weekly without mastering either.",
                "Over-Automation: Automating everything and losing your critical thinking skills.",
                "Generic Output: Producing bland content that sounds exactly like a robot.",
                "No Feedback Loop: Never refining the output or learning from mistakes."
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-400 bg-slate-900/50 p-4 rounded-lg border border-red-900/20">
                  <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </FadeIn>

        <FadeIn delay={0.2}>
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-brand-400 mb-6 flex items-center gap-2">
              <CheckCircle className="h-6 w-6" /> The Toolkit Way
            </h3>
            <ul className="space-y-4">
              {[
                "Strategic Frameworks: Clarify → Create → Critique → Customize.",
                "Tool Mastery: Deep understanding of 1-2 tools and their specific strengths.",
                "Strategic Hybrid: Automate routine, keep strategy manual.",
                "Authentic Voice: Using AI for clarity, but infusing your unique story.",
                "Iterative Growth: Treat every output as V1.0 and refine for excellence."
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-200 bg-brand-900/10 p-4 rounded-lg border border-brand-500/20">
                  <CheckCircle className="h-5 w-5 text-brand-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </FadeIn>
      </div>
    </Section>
  );
};