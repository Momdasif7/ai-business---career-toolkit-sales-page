import React from 'react';
import { ArrowRight, Lock } from 'lucide-react';

interface BuyButtonProps {
  className?: string;
  text?: string;
  subtext?: string;
  fullWidth?: boolean;
}

const CHECKOUT_URL = "https://www.checkout-ds24.com/product/658074";

export const BuyButton: React.FC<BuyButtonProps> = ({ 
  className = "", 
  text = "Get The Toolkit Now", 
  subtext = "Instant Digital Access • Secure Checkout",
  fullWidth = false 
}) => {
  return (
    <div className={`flex flex-col items-center ${fullWidth ? 'w-full' : ''}`}>
      <a 
        href={CHECKOUT_URL}
        className={`
          group relative flex items-center justify-center gap-3 overflow-hidden rounded-lg bg-gradient-to-r from-brand-500 to-accent-600 px-8 py-4 font-bold text-white transition-all hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(14,165,233,0.5)] focus:outline-none focus:ring-2 focus:ring-brand-400 focus:ring-offset-2 focus:ring-offset-slate-900
          ${fullWidth ? 'w-full' : ''}
          ${className}
        `}
      >
        <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-1000 group-hover:animate-[shimmer_1.5s_infinite]"></div>
        <span className="relative z-10 text-lg uppercase tracking-wide">{text}</span>
        <ArrowRight className="relative z-10 h-5 w-5 transition-transform group-hover:translate-x-1" />
      </a>
      {subtext && (
        <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
          <Lock className="h-3 w-3" />
          <span>{subtext}</span>
        </div>
      )}
    </div>
  );
};